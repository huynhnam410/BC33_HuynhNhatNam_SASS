/*
MVC : 
Models: Chứa các file js định nghĩa kiểu dữ liệu (prototype hay class)
View: Chứa các giao diện html css ...
Controller: Chứa các file javascript dom trên giao diện đó

*/